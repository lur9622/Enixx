$.stellar({
  horizontalScrolling: false,
  responsive:true
});
